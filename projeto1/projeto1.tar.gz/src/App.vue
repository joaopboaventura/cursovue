<template>
  <div id="app" >
    <!-- <img alt="Vue logo" src="./assets/logo.png"> -->
    <!-- <HelloWorld msg="Welcome to Your Vue.js App"/> -->
    <titulo texto="Alterado no App" cor="orange"></titulo>
    <resultados :pessoasProp="pessoas"></resultados>
  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'app',
  components: {
    // HelloWorld
  },
    data: function() {
  return {
      pessoas: [{
                        nome: 'Paulo',
                        cargo: 'Analista',
                        unidade: 'Tupis'
                    },
                    {
                        nome: 'Natália',
                        cargo: 'Redatora',
                        unidade: 'Fazenda'
                    }
                ],
      
    }
  }  

         
  
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
