<template>
<div>
        <table class="table" style="width:70%" name="resultados">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Nome</th>
                    <th scope="col">Cargo</th>
                    <th scope="col">Unidade</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="pessoa in pessoasProp" :key="pessoa.nome">
                    <td v-text="pessoa.nome"></td>
                    <td v-text="pessoa.cargo"></td>
                    <td v-text="pessoa.unidade"></td>
                </tr>
                <tr v-if="(!pessoasProp)">
                    <td colspan="3">SEM DADOS</td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
export default {
props: ['pessoasProp'],
    }
</script>

<style>
</style>