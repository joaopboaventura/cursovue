<template>
    <div style="width: 70%">
    <h1 :style="{color: cor}">TESTE {{texto}}</h1>
    </div>
</template>

<script>
export default {
    props: {
        texto: {
                    type: String,
                    default: 'Texto de exemplo',
                },
                cor: {
                    type: String,
                    default: 'red',
                }
    }


}
</script>

<style>

</style>