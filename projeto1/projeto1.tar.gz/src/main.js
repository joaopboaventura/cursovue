import Vue from 'vue'
import App from './App.vue'
import Titulo from './components/titulo.vue'
import Resultados from './components/resultados.vue'
Vue.config.productionTip = false;

Vue.component('titulo',Titulo);
Vue.component('resultados',Resultados);
 

new Vue({
  render: h => h(App),
}).$mount('#app');
